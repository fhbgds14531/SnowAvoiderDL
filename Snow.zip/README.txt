Thank you for downloading Snow Avoider! 

Here's everything you have to do to get started:



               1.) Run Snow_Avoider.jar to play!      
--




Snow Avoider! is a Copyright of James Hamann, 2014.--
